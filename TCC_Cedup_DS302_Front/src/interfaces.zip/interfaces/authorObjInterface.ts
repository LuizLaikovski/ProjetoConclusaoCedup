import type { Author } from "./AuthorInterface";
import type { image } from "./imageInterface";

export interface AuthorInfo {
    authors: Author;
    image: image;
}