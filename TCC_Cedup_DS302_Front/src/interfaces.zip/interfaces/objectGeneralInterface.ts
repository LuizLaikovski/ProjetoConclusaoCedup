import type { AuthorInfo } from "./authorObjInterface";
import type { Book } from "./BookInterface";
import type { image } from "./imageInterface";

export interface objectGeneral {
    books: Book;
    imagesBook: image[];
    authorsInfo: AuthorInfo[];
}