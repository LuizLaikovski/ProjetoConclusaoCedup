export interface image {
    id: string;
    src: string;
    alt:string;
}