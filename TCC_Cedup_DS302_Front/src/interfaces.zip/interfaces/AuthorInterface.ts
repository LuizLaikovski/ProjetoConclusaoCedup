export interface Author {
    id: string;
    name: string;
    yearBorn: Date;
    yearDied?: Date;
    description: string;
    books: string[];
    images: string[];
}