import type { archive } from "./archiveInterface";

export interface Book {
    id: string;
    title: string;
    path: string;
    numPages: number;
    rating: number;
    yearPublished: Date;
    description: string;
    authors: string[];
    images: string[];
    archive: archive;
}