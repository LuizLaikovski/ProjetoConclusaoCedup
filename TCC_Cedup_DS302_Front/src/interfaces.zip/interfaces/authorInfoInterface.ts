export interface authorInfo {
    authorObj: authorInfo[];
}