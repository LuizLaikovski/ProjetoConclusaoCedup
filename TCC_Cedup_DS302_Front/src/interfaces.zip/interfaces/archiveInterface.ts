export interface archive {
    src: string;
    alt: string;
}